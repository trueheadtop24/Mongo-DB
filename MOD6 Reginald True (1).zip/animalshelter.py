from pymongo import MongoClient
from pymongo.errors import ConnectionFailure

class AnimalShelter:
    """CRUD operations for the 'animals' collection in MongoDB"""

    def __init__(self, username, password, host='localhost', port=27017):
        try:
            # Connect to MongoDB with username and password
            self.client = MongoClient(f"mongodb://{username}:{password}@{host}:{port}/")
            self.database = self.client["AAC"]
            self.collection = self.database["animals"]
        except ConnectionFailure as e:
            print(f"Error connecting to MongoDB: {e}")

    def create(self, data):
        """Insert one document into the collection."""
        if data is not None:
            result = self.collection.insert_one(data)
            return result.acknowledged
        else:
            return False

    def read(self, query):
        """Read documents that match the query."""
        if query is not None:
            return list(self.collection.find(query))
        else:
            return []

    def update(self, query, new_values):
        """Update documents that match the query."""
        if query and new_values:
            result = self.collection.update_many(query, {"$set": new_values})
            return result.modified_count
        else:
            return 0

    def delete(self, query):
        """Delete documents that match the query."""
        if query:
            result = self.collection.delete_many(query)
            return result.deleted_count
        else:
            return 0

